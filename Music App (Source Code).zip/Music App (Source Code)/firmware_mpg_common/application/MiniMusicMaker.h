/**********************************************************************************************************************
File: MiniMusicMaker.h                                                                

----------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------

Description:
Header file for MiniMusicMaker.c

**********************************************************************************************************************/

#ifndef __MINI_MUSIC_MAKER_H
#define __MINI_MUSIC_MAKER_H

/**********************************************************************************************************************
Type Definitions
**********************************************************************************************************************/


/**********************************************************************************************************************
Constants / Definitions
**********************************************************************************************************************/
/* Required constants for ANT channel configuration */
#define ANT_CHANNEL_USERAPP             (u8)0                 /* Channel 0 - 7 */
#define ANT_SERIAL_LO_USERAPP           (u8)0x28              /* Low byte of two-byte Device # */
#define ANT_SERIAL_HI_USERAPP           (u8)0x28              /* High byte of two-byte Device # */
#define ANT_DEVICE_TYPE_USERAPP         (u8)0                 /* 1 - 255 */
#define ANT_TRANSMISSION_TYPE_USERAPP   (u8)0                 /* 1-127 (MSB is pairing bit) */
#define ANT_CHANNEL_PERIOD_LO_USERAPP   (u8)0x1A              /* Low byte of two-byte channel period 0x0001 - 0x7fff */
#define ANT_CHANNEL_PERIOD_HI_USERAPP   (u8)0x1A              /* High byte of two-byte channel period */
#define ANT_FREQUENCY_USERAPP           (u8)50                /* 2400MHz + this number 0 - 99 */
#define ANT_TX_POWER_USERAPP            RADIO_TX_POWER_0DBM   /* RADIO_TX_POWER_0DBM, RADIO_TX_POWER_MINUS5DBM, RADIO_TX_POWER_MINUS10DBM, RADIO_TX_POWER_MINUS20DBM */

#define TIMEOUT_VALUE                   (u32)20000             /* Maximum allowed timeout value for any transition state */

/* G_u32MiniMusicMakerFlags */
#define _CHANNEL_SYNCED                 0x00000001            /* Set when channel is synced */


/**********************************************************************************************************************
Function Declarations
**********************************************************************************************************************/

/*--------------------------------------------------------------------------------------------------------------------*/
/* Public functions                                                                                                   */
/*--------------------------------------------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------------------------------------------*/
/* Protected functions                                                                                                */
/*--------------------------------------------------------------------------------------------------------------------*/
void MiniMusicMakerInitialize(void);
void MiniMusicMakerRunActiveState(void);

/*--------------------------------------------------------------------------------------------------------------------*/
/* Private functions                                                                                                  */
/*--------------------------------------------------------------------------------------------------------------------*/
void PlayNote(u8 note);
void DrawLines(void);
void DrawNote(u8 note, int column);
void SetNote(PixelAddressType aa);

/***********************************************************************************************************************
State Machine Declarations
***********************************************************************************************************************/
static void MiniMusicMakerSM_Idle(void);    
static void MiniMusicMakerSM_WaitChannelOpen(void);
static void MiniMusicMakerSM_ChannelOpen(void);
static void MiniMusicMakerSM_WaitChannelClose(void);
static void MiniMusicMakerSM_Instrument(void);
static void MiniMusicMakerSM_GoBackToStart(void);

static void MiniMusicMakerSM_Error(void);         
static void MiniMusicMakerSM_FailedInit(void);        


#endif /* __MINI_MUSIC_MAKER_H */


/*--------------------------------------------------------------------------------------------------------------------*/
/* End of File                                                                                                        */
/*--------------------------------------------------------------------------------------------------------------------*/
