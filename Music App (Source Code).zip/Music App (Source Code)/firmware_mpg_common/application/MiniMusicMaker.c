/**********************************************************************************************************************
File: MiniMusicMaker.c                                                                

----------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------

Description:

Mode 1: Receives ANT wireless signals and plays the corresponding musical notes 
on the buzzer and displays the notes on the screen. This mode also has a load
music state to wait for several sets of notes to arrive.

Mode 2: The user uses the verticle captouch slider to select the musical note to
play and presses BUTTON1 to play and display the note.

------------------------------------------------------------------------------------------------------------------------
API:

Public functions:


Protected System functions:
void MiniMusicMakerInitialize(void)
Runs required initialzation for the task.  Should only be called once in main init section.

void MiniMusicMakerRunActiveState(void)
Runs current task state.  Should only be called once in main loop.


**********************************************************************************************************************/

#include "configuration.h"

/***********************************************************************************************************************
Global variable definitions with scope across entire project.
All Global variable names shall start with "G_"
***********************************************************************************************************************/
/* New variables */
volatile u32 G_u32MiniMusicMakerFlags;                       /* Global state flags */

/*--------------------------------------------------------------------------------------------------------------------*/
/* Existing variables (defined in other files -- should all contain the "extern" keyword) */
extern AntSetupDataType G_stAntSetupData;                         /* From ant.c */

extern u32 G_u32AntApiCurrentDataTimeStamp;                       /* From ant_api.c */
extern AntApplicationMessageType G_eAntApiCurrentMessageClass;    /* From ant_api.c */
extern u8 G_au8AntApiCurrentData[ANT_APPLICATION_MESSAGE_BYTES];  /* From ant_api.c */

extern volatile u32 G_u32SystemFlags;                  /* From main.c */
extern volatile u32 G_u32ApplicationFlags;             /* From main.c */

extern volatile u32 G_u32SystemTime1ms;                /* From board-specific source file */
extern volatile u32 G_u32SystemTime1s;                 /* From board-specific source file */

/***********************************************************************************************************************
Global variable definitions with scope limited to this local application.
Variable names shall start with "MiniMusicMaker_" and be declared as static.
***********************************************************************************************************************/
static u32 MiniMusicMaker_u32DataMsgCount = 0;             /* Counts the number of ANT_DATA packets received */
//static u32 MiniMusicMaker_u32TickMsgCount = 0;             /* Counts the number of ANT_TICK packets received */

static fnCode_type MiniMusicMaker_StateMachine;            /* The state machine function pointer */
static u32 MiniMusicMaker_u32Timeout;                      /* Timeout counter used across states */

/**********************************************************************************************************************
Function Definitions
**********************************************************************************************************************/

/*--------------------------------------------------------------------------------------------------------------------*/
/* Public functions                                                                                                   */
/*--------------------------------------------------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------------------------------------------------*/
/* Protected functions                                                                                                */
/*--------------------------------------------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------------------------------------------------
Function: MiniMusicMakerInitialize

Description:
Initializes the State Machine and its variables. Configures ANT.
Places a welcome message on the screen.

Requires:
  -

Promises:
  - 
*/
void MiniMusicMakerInitialize(void)
{
  u8 au8WelcomeMessage[] =  "PRESS BUTTON0";
  u8 au8WelcomeMessage2[] = "TO PLAY MUSIC";

  /* Clear screen and place start messages */
  PixelAddressType sStringLocation = {LCD_SMALL_FONT_LINE2, 23}; 
  LcdClearScreen();
  LcdLoadString(au8WelcomeMessage, LCD_FONT_SMALL, &sStringLocation); 
  PixelAddressType sStringLocation2 = {LCD_SMALL_FONT_LINE3, 23};
  LcdLoadString(au8WelcomeMessage2, LCD_FONT_SMALL, &sStringLocation2);

  /* Configure ANT for this application */
  G_stAntSetupData.AntChannel          = ANT_CHANNEL_USERAPP;
  G_stAntSetupData.AntSerialLo         = ANT_SERIAL_LO_USERAPP;
  G_stAntSetupData.AntSerialHi         = ANT_SERIAL_HI_USERAPP;
  G_stAntSetupData.AntDeviceType       = ANT_DEVICE_TYPE_USERAPP;
  G_stAntSetupData.AntTransmissionType = ANT_TRANSMISSION_TYPE_USERAPP;
  G_stAntSetupData.AntChannelPeriodLo  = ANT_CHANNEL_PERIOD_LO_USERAPP;
  G_stAntSetupData.AntChannelPeriodHi  = ANT_CHANNEL_PERIOD_HI_USERAPP;
  G_stAntSetupData.AntFrequency        = ANT_FREQUENCY_USERAPP;
  G_stAntSetupData.AntTxPower          = ANT_TX_POWER_USERAPP;
  
  /* If good initialization, set state to Idle */
  if( AntChannelConfig(ANT_SLAVE) )
  {    
    MiniMusicMaker_StateMachine = MiniMusicMakerSM_Idle;
  }
  else
  {
    /* The task isn't properly initialized, so shut it down and don't run */
    LedBlink(RED0, LED_4HZ);
    MiniMusicMaker_StateMachine = MiniMusicMakerSM_Error;
  }
} /* end MiniMusicMakerInitialize() */

/*----------------------------------------------------------------------------------------------------------------------
Function MiniMusicMakerRunActiveState()

Description:
Selects and runs one iteration of the current state in the state machine.
All state machines have a TOTAL of 1ms to execute, so on average n state machines
may take 1ms / n to execute.

Requires:
  - State machine function pointer points at current state

Promises:
  - Calls the function to pointed by the state machine function pointer
*/
void MiniMusicMakerRunActiveState(void)
{
  MiniMusicMaker_StateMachine();
} /* end MiniMusicMakerRunActiveState */

/*--------------------------------------------------------------------------------------------------------------------*/
/* Private functions                                                                                                  */
/*--------------------------------------------------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------------------------------------------------
Function DrawLines()

Description:
Draws 5 horizontal lines across the screen to be used to draw musical notes

*/
void DrawLines(void)
{
  PixelAddressType aa = {15, 0};
  
  for (u8 j = 0; j < 5; j++)
  {
    aa.u16PixelColumnAddress = 0;
    for (u8 i = 0; i < 127; i++)
    {
      LcdSetPixel(&aa);
      aa.u16PixelColumnAddress++;
    }
    aa.u16PixelRowAddress += 6;
  }
}

/*----------------------------------------------------------------------------------------------------------------------
Function SetNote(PixelAddressType aa)

Description:
Draws a note on the screen setting the appropriate LCD pixels at the 
indicated position in the parameter.

*/
void SetNote(PixelAddressType aa)
{
  for (u8 i = 0; i < 4; i++)
  {
    LcdSetPixel(&aa);
    aa.u16PixelColumnAddress++;
  }
  aa.u16PixelColumnAddress -= 2;
  aa.u16PixelRowAddress--;
  LcdSetPixel(&aa);
  aa.u16PixelColumnAddress--;
  LcdSetPixel(&aa);
  aa.u16PixelRowAddress += 2;
  aa.u16PixelColumnAddress--;
  for (u8 i = 0; i < 4; i++)
  {
    LcdSetPixel(&aa);
    aa.u16PixelColumnAddress++;
  }
  aa.u16PixelColumnAddress -= 4;
  aa.u16PixelRowAddress++;
  for (u8 i = 0; i < 4; i++)
  {
    LcdSetPixel(&aa);
    aa.u16PixelColumnAddress++;
  }
  aa.u16PixelColumnAddress -= 2;
  aa.u16PixelRowAddress++;
  LcdSetPixel(&aa);
  aa.u16PixelColumnAddress--;
  LcdSetPixel(&aa);
}

/*----------------------------------------------------------------------------------------------------------------------
Function DrawNote(u8 note, int column)

Description:
Interprets a char value to the note that should be drawn and determines
the location of the note. Calls SetNote(PixelAddressType aa) to place the
note on the screen.

*/
void DrawNote(u8 note, int column)
{
  PixelAddressType aa = {15, column * 9 + 2};
  
  if (note == '1')
  {
    aa.u16PixelRowAddress = 44;
    SetNote(aa);
    aa.u16PixelRowAddress++;
    aa.u16PixelColumnAddress -= 2;
    for (u8 i = 0; i < 8; i++)
    {
      LcdSetPixel(&aa);
      aa.u16PixelColumnAddress++;
    }
  }
  else if (note == '2')
  {
    aa.u16PixelRowAddress = 41;
    SetNote(aa);  
  }
  else if (note == '3')
  {
    aa.u16PixelRowAddress = 38;
    SetNote(aa); 
  }
  else if (note == '4')
  {
    aa.u16PixelRowAddress = 35;
    SetNote(aa);  
  }
  else if (note == '5')
  {
    aa.u16PixelRowAddress = 32;
    SetNote(aa); 
  }
  else if (note == 'A')
  {
    aa.u16PixelRowAddress = 29;
    SetNote(aa);   
  }
  else if (note == 'B')
  {
    aa.u16PixelRowAddress = 26;
    SetNote(aa); 
  }
  else if (note == 'C')
  {
    aa.u16PixelRowAddress = 23;
    SetNote(aa);  
  }
  else if (note == 'D')
  {
    aa.u16PixelRowAddress = 20;
    SetNote(aa);  
  }
  else if (note == 'E')
  {
    aa.u16PixelRowAddress = 17;
    SetNote(aa);  
  }
  else if (note == 'F')
  {
    aa.u16PixelRowAddress = 14;
    SetNote(aa);  
  }
  else if (note == '0')
  {
    aa.u16PixelRowAddress = 26;
    for (u8 i = 0; i < 4; i++)
    {
      LcdSetPixel(&aa);
      aa.u16PixelColumnAddress++;
    } 
    aa.u16PixelRowAddress = 25;
    aa.u16PixelColumnAddress -=4;
    for (u8 i = 0; i < 4; i++)
    {
      LcdSetPixel(&aa);
      aa.u16PixelColumnAddress++;
    } 
  }
}

/*----------------------------------------------------------------------------------------------------------------------
Function PlayNote(u8 note)

Description:
Interprets a char value to the note that should be played using the buzzer.
If the note recieved is '0', it turns off the buzzer.

*/
void PlayNote(u8 note)
{
  if (note == '1')
  {
    PWMAudioSetFrequency(BUZZER1,C4);
    PWMAudioOn(BUZZER1);
  }
  else if (note == '2')
  {
    PWMAudioSetFrequency(BUZZER1,D4);
    PWMAudioOn(BUZZER1);
  }
  else if (note == '3')
  {
    PWMAudioSetFrequency(BUZZER1,E4);
    PWMAudioOn(BUZZER1);
  }
  else if (note == '4')
  {
    PWMAudioSetFrequency(BUZZER1,F4);
    PWMAudioOn(BUZZER1);
  }
  else if (note == '5')
  {
    PWMAudioSetFrequency(BUZZER1,G4);
    PWMAudioOn(BUZZER1);
  }
  else if (note == 'A')
  {
    PWMAudioSetFrequency(BUZZER1,A4);
    PWMAudioOn(BUZZER1);
  }
  else if (note == 'B')
  {
    PWMAudioSetFrequency(BUZZER1,B4);
    PWMAudioOn(BUZZER1);
  }
  else if (note == 'C')
  {
    PWMAudioSetFrequency(BUZZER1,C5);
    PWMAudioOn(BUZZER1);
  }
  else if (note == 'D')
  {
    PWMAudioSetFrequency(BUZZER1,D5);
    PWMAudioOn(BUZZER1);
  }
  else if (note == 'E')
  {
    PWMAudioSetFrequency(BUZZER1,E5);
    PWMAudioOn(BUZZER1);
  }
  else if (note == 'F')
  {
    PWMAudioSetFrequency(BUZZER1,F5);
    PWMAudioOn(BUZZER1);
  }
  else if (note == '0')
  {
    PWMAudioOff(BUZZER1);   
  }
}

/**********************************************************************************************************************
State Machine Function Definitions
**********************************************************************************************************************/

/*-------------------------------------------------------------------------------------------------------------------*/
/* Wait for a message to be queued */
static void MiniMusicMakerSM_Idle(void)
{
  /* Look for BUTTON 0 to open channel */
  if(WasButtonPressed(BUTTON0))
  {
    /* Got the button, so complete one-time actions before next state */
    ButtonAcknowledge(BUTTON0);
    
    u8 au8WaitingMessage[] = "Waiting...";
    PixelAddressType sStringLocation = {LCD_SMALL_FONT_LINE0, LCD_LEFT_MOST_COLUMN}; 

    /* Clear screen and place waiting message */
    LcdClearScreen();
    LcdLoadString(au8WaitingMessage, LCD_FONT_SMALL, &sStringLocation); 
    
    DrawLines();
  
    /* Queue open channel*/
    AntOpenChannel();   
    
    /* Set timer and advance states */
    MiniMusicMaker_u32Timeout = G_u32SystemTime1ms;
    MiniMusicMaker_StateMachine = MiniMusicMakerSM_WaitChannelOpen; 
  }
} /* end MiniMusicMakerSM_Idle() */
     

/*-------------------------------------------------------------------------------------------------------------------*/
/* Wait for channel to open */
static void MiniMusicMakerSM_WaitChannelOpen(void)
{
  /* Monitor the channel status to check if channel is opened */
  if(AntRadioStatus() == ANT_OPEN)
  {     
    MiniMusicMaker_StateMachine = MiniMusicMakerSM_ChannelOpen;
  }
  
  /* Check for timeout */
  if( IsTimeUp(&MiniMusicMaker_u32Timeout, TIMEOUT_VALUE) )
  {
    AntCloseChannel();  
    LcdClearScreen();

    MiniMusicMaker_StateMachine = MiniMusicMakerSM_Idle;
  }
    
} /* end MiniMusicMakerSM_WaitChannelOpen() */

/* This defines the temp of the music to be played. Set to a higher value to slow down the music */
#define SPEED 200

/*------------------------------------------------------------------------------------------------------------------
The state where it recieves ant signals and plays and draws the corresponding musical notes
-------------------------------------------------------------------------------------------------------------------*/
/* Channel is open, so monitor data */
static void MiniMusicMakerSM_ChannelOpen(void)
{
  static char au8DataContent[] = "xxxxxxxxxxxxxxxx";
  static char au8LastAntData[ANT_APPLICATION_MESSAGE_BYTES] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
  static char au8TestMessage[] = {0, 0, 0, 0, 0xA5, 0, 0, 0};
  static char au8LastNotes[] = "xxxxxxxxxxxxxxxx";
  static char NotesQueue[20][17];
  static int QueueStart = 0;
  static int QueueEnd = 0;
  static int CurrentNoteIndex = 0;
  bool bGotNewData;
  static char au8CurrentNotes[] = "9xxxxxxxxxxxxxxx";
  static int count = 10000;
  static bool stateLoadMusic = FALSE;
  static bool justStarted = TRUE;
  
  /* Reset the queue at the start */
  if (justStarted)
  {
    for (int i = 0; i < 20; i++)
    {
      /* A '9' on the first column indicates an unused slot on the queue */
      NotesQueue[i][0] = '9';
    }
    justStarted = FALSE;
  }
  
  /* This determines which note to play from au8CurrentNotes */
  CurrentNoteIndex = count / SPEED;
  
  /* Only play a new note every "SPEED" cycles */
  if (count % SPEED == 0 && CurrentNoteIndex <= 13)
  {
    PlayNote(au8CurrentNotes[CurrentNoteIndex]);
    DrawNote(au8CurrentNotes[CurrentNoteIndex], CurrentNoteIndex);
  }
  else if (CurrentNoteIndex > 13)
  {
    /* Turn off the buzzer if the end of au8CurrentNotes is reached */
    PWMAudioOff(BUZZER1);
  }
  else if (au8CurrentNotes[CurrentNoteIndex + 1] >= '6' && au8CurrentNotes[CurrentNoteIndex + 1] <= '9') 
  {
    /* If the next note is from 6-9, do nothing and just hold the note */
  }
  else if (count % SPEED == (SPEED - 20))
  {
    /* Turn off buzzer briefly before the next note is to be played */
    PWMAudioOff(BUZZER1);
  }
  
  /* Increment the counter used for the timing of the notes to be played */
  count++;
  
  /* Initiate a new set of notes in the queue once the previous set is done playing */
  if ((NotesQueue[QueueStart][0] != '9') && (CurrentNoteIndex > 13) && (!stateLoadMusic))
  { 
      /* Setting count to 0 allows for the notes to be played*/
      count = 0;
      
      /* Set up the LCD with the lines*/
      LcdClearScreen();
      DrawLines();
      
      PixelAddressType sStringLocation = {LCD_SMALL_FONT_LINE7, 2};  
      
      /* Get the notes from the queue */  
      strcpy(au8CurrentNotes, NotesQueue[QueueStart]);
      
      /* A '9' at the first column is used to indicate an open slot on the queue */
      NotesQueue[QueueStart][0] = '9';
      
      /* The QueueStart goes to the next position and wraps around if at the end */
      QueueStart++;
      if (QueueStart >= 19)
      {
        QueueStart = 0;
      }
      
      /* Show the notes on LCD */  
      unsigned char Printme[14];
      strcpy((char*)Printme, au8CurrentNotes);  
      for(u8 i = 0; i < 14; i++)
      {
        if      (Printme[i] == '1') Printme[i] = 'C';
        else if (Printme[i] == '2') Printme[i] = 'D';
        else if (Printme[i] == '3') Printme[i] = 'E';
        else if (Printme[i] == '4') Printme[i] = 'F';
        else if (Printme[i] == '5') Printme[i] = 'G';
        else if (Printme[i] == '0') Printme[i] = ' '; 
        else if (Printme[i] == '6') Printme[i] = ' '; 
        else if (Printme[i] == '7') Printme[i] = ' '; 
        else if (Printme[i] == '8') Printme[i] = ' '; 
        else if (Printme[i] == '9') Printme[i] = ' '; 
      }
      LcdLoadString2(Printme, LCD_FONT_SMALL, &sStringLocation);
  } /* end if(DoNextNotes) */
 
  /* Always check for ANT messages */
  if( AntReadData() )
  {
     /* New data message: check what it is */
    if(G_eAntApiCurrentMessageClass == ANT_DATA)
    {
      MiniMusicMaker_u32DataMsgCount++;
      
      /* Check if the new data is the same as the old data and update as we go */
      bGotNewData = FALSE;
      for(u8 i = 0; i < ANT_APPLICATION_MESSAGE_BYTES; i++)
      {
        if(G_au8AntApiCurrentData[i] != au8LastAntData[i])
        {
          au8LastAntData[i] = G_au8AntApiCurrentData[i];
          au8DataContent[2 * i] = HexToASCIICharUpper(G_au8AntApiCurrentData[i] / 16);
          au8DataContent[2 * i + 1] = HexToASCIICharUpper(G_au8AntApiCurrentData[i] % 16); 
        }
      }
      
      /* Check if the new notes are the same as the old notes and update as we go */
      for(u8 i = 0; i < 14; i++)
      {
        if(au8DataContent[i] != au8LastNotes[i])
        {
          bGotNewData = TRUE;
          au8LastNotes[i] = au8DataContent[i];
        }
      }
      
      /* Got a new set of notes to add to the queue */
      if(bGotNewData)
      { 
        /* An '8' on the first column puts it in and out of the load music state */
        if (au8DataContent[0] == '8')
        {
          if (!stateLoadMusic)
          {
            stateLoadMusic = TRUE;
            u8 au8PlayingMessage[] = "Loading Music...";    
            PixelAddressType sStringLocation = {LCD_SMALL_FONT_LINE0, LCD_LEFT_MOST_COLUMN}; 
            LcdLoadString(au8PlayingMessage, LCD_FONT_SMALL, &sStringLocation);
            au8TestMessage[4] = 0x88;
          }
          else
          {
            stateLoadMusic = FALSE;
            u8 au8PlayingMessage[] = "Finished loading...";    
            PixelAddressType sStringLocation = {LCD_SMALL_FONT_LINE0, LCD_LEFT_MOST_COLUMN}; 
            LcdLoadString(au8PlayingMessage, LCD_FONT_SMALL, &sStringLocation);
            au8TestMessage[4] = 0x88;   
          }
        }
        else if (au8DataContent[0] == '9')
        {
          /* Do nothing */
        }
        else
        {
          /* Normal data, add the notes to the queue */
          strcpy(NotesQueue[QueueEnd], au8DataContent);
          
          /* Update the end of the queue */
          QueueEnd++;
          if (QueueEnd >= 19)
          {
            QueueEnd = 0;
          }
          au8TestMessage[4] = 0x11;
        }
        
        /* Update our local message counter and send the message back */
        au8TestMessage[7]++;
        if(au8TestMessage[7] == 0)
        {
          au8TestMessage[6]++;
          if(au8TestMessage[6] == 0)
          {
            au8TestMessage[5]++;
          }
        }
        AntQueueBroadcastMessage((u8*)au8TestMessage);
      }
    } /* end if(G_eAntApiCurrentMessageClass == ANT_DATA) */
  } /* end AntReadData() */
  
  /* A slave channel can close on its own, so explicitly check channel status */
  if(AntRadioStatus() != ANT_OPEN)
  {
    /* Queue open channel*/
    AntOpenChannel();
  } /* if(AntRadioStatus() != ANT_OPEN) */
 
  /* Check for BUTTON0 to close channel */
  if(WasButtonPressed(BUTTON0))
  {
    /* Got the button, so complete one-time actions before next state */
    ButtonAcknowledge(BUTTON0);
    
    /* Reset variables */
    CurrentNoteIndex = 0;
    count = 10000;
    stateLoadMusic = FALSE;
    justStarted = TRUE;
    au8DataContent[0] = 'x';
    au8LastAntData[0] = 0xFF;
    au8LastNotes[0] = 'x';
    QueueStart = 0;
    QueueEnd = 0;
    au8CurrentNotes[0] = '9';
    au8CurrentNotes[1] = 'x';
    
    /* Queue close channel */
    AntCloseChannel();
    
    /* Turn off buzzer and clear the screen */
    PWMAudioOff(BUZZER1);
    LcdClearScreen();
    
    /* Set timer and advance states */
    MiniMusicMaker_u32Timeout = G_u32SystemTime1ms;
    MiniMusicMaker_StateMachine = MiniMusicMakerSM_WaitChannelClose;
  } /* end if(WasButtonPressed(BUTTON0)) */
       
} /* end MiniMusicMakerSM_ChannelOpen() */


/*-------------------------------------------------------------------------------------------------------------------*/
/* Wait for channel to close */
static void MiniMusicMakerSM_WaitChannelClose(void)
{
  /* Monitor the channel status to check if channel is closed */
  if(AntRadioStatus() == ANT_CLOSED)
  {
    u8 au8WelcomeMessage[] = "USE BUTTON 1 AND ";
    u8 au8WelcomeMessage2[] = "CAPTOUCH TO PLAY";
    
    /* Clear screen and place start messages */
    PixelAddressType sStringLocation = {LCD_SMALL_FONT_LINE2, 20}; 
    PixelAddressType sStringLocation2 = {LCD_SMALL_FONT_LINE3, 20};
    LcdClearScreen();
    LcdLoadString(au8WelcomeMessage, LCD_FONT_SMALL, &sStringLocation); 
    LcdLoadString(au8WelcomeMessage2, LCD_FONT_SMALL, &sStringLocation2);
  
    /* Set up CapTouch for the next state */
    CapTouchOn();
    ButtonAcknowledge(BUTTON1);
    
    MiniMusicMaker_StateMachine = MiniMusicMakerSM_Instrument;
  }    
} /* end MiniMusicMakerSM_WaitChannelClose() */

/*-------------------------------------------------------------------------------------------------------------------*/
/* The State where the user uses the captouch slider and BUTTON1 to play musical notes */
static void MiniMusicMakerSM_Instrument(void)
{
  static u8 note = '1';          /* Note to play based on captouch slider */
  static int column = 0;         /* Place to draw the note (number from 0-13) */
  static bool setLines = TRUE;   /* Indicates to refresh the screen with new lines */
  static u8 currentNote = 0;     /* Stores the current note being played */

  /* Determine the note to play based on the verticle captouch position */
  if      (CaptouchCurrentVSlidePosition() < 30)  note = 'C';
  else if (CaptouchCurrentVSlidePosition() < 47)  note = 'B';
  else if (CaptouchCurrentVSlidePosition() < 83)  note = 'A';
  else if (CaptouchCurrentVSlidePosition() < 135) note = '5';
  else if (CaptouchCurrentVSlidePosition() < 165) note = '4';
  else if (CaptouchCurrentVSlidePosition() < 187) note = '3';
  else if (CaptouchCurrentVSlidePosition() < 230) note = '2';
  else                                            note = '1';
 
  /* If Button1 is pressed, play and draw the note */
  if(WasButtonPressed(BUTTON1))
  {
    /* Refresh screen if needed */
    if (setLines)
    {
      LcdClearScreen();
      DrawLines();
      setLines = FALSE;
    }
    ButtonAcknowledge(BUTTON1);
    
    /* Play and draw the note */
    PlayNote(note);
    DrawNote(note, column);
    currentNote = note;
    
    /* If the right side of the screen is reached, go back to the left
    /* side and indicate that the screen should be refreshed before the
    /* next note is played */
    column++;
    if (column > 13)
    {
      setLines = TRUE;
      column = 0;
    }
  }
  
  /* Similar to code inside the WasButtonPressed conditional but also
  /* allows the user to change the note while holding down the button */
  if (IsButtonPressed(BUTTON1))
  {
    if (note != currentNote)
    {
      if (setLines)
      {
        LcdClearScreen();
        DrawLines();
        setLines = FALSE;
      }
      PlayNote(note);
      DrawNote(note, column);
      currentNote = note;
      column++;
      if (column > 13)
      {
        setLines = TRUE;
        column = 0;
      }
    }
  }
  else
  {
    /* The buzzer is off when Button1 is not pressed down */
    PWMAudioOff(BUZZER1);
  }
  
   /* Check for BUTTON0 to go to next state */
  if(WasButtonPressed(BUTTON0))
  {
    /* Got the button, so complete one-time actions before next state */
    ButtonAcknowledge(BUTTON0);
    
    /* Reset Variables */
    setLines = TRUE;
    column = 0;
    currentNote = 0;
    
    /* Turn off buzzer and captouch*/
    PWMAudioOff(BUZZER1);
    CapTouchOff();
    
    /* Set timer and advance states */
    MiniMusicMaker_u32Timeout = G_u32SystemTime1ms;
    MiniMusicMaker_StateMachine = MiniMusicMakerSM_GoBackToStart;
  } /* end if(WasButtonPressed(BUTTON0)) */
}

/*-------------------------------------------------------------------------------------------------------------------*/
/* Puts up the starting message and resets the state machine back to MiniMusicMakerSM_Idle*/
static void MiniMusicMakerSM_GoBackToStart(void)
{
  u8 au8WelcomeMessage[] =  "PRESS BUTTON0";
  u8 au8WelcomeMessage2[] = "TO PLAY MUSIC";
  PixelAddressType sStringLocation = {LCD_SMALL_FONT_LINE2, 23}; 
  PixelAddressType sStringLocation2 = {LCD_SMALL_FONT_LINE3, 23};
  
  /* Clear screen and place start messages */
  LcdClearScreen();
  LcdLoadString(au8WelcomeMessage, LCD_FONT_SMALL, &sStringLocation); 
  LcdLoadString(au8WelcomeMessage2, LCD_FONT_SMALL, &sStringLocation2);
  
  /* Go back to the initial, idle state */
  MiniMusicMaker_StateMachine = MiniMusicMakerSM_Idle;
}


/*-------------------------------------------------------------------------------------------------------------------*/
/* Handle an error */
static void MiniMusicMakerSM_Error(void)          
{
  u8 au8WelcomeMessage[] =  "PRESS BUTTON0";
  u8 au8WelcomeMessage2[] = "TO PLAY MUSIC";
  PixelAddressType sStringLocation = {LCD_SMALL_FONT_LINE2, 23}; 
  PixelAddressType sStringLocation2 = {LCD_SMALL_FONT_LINE3, 23};
  
  /* Clear screen and place start messages */
  LcdClearScreen();
  LcdLoadString(au8WelcomeMessage, LCD_FONT_SMALL, &sStringLocation); 
  LcdLoadString(au8WelcomeMessage2, LCD_FONT_SMALL, &sStringLocation2);
  
  /* Reset back to initial state */
  MiniMusicMaker_StateMachine = MiniMusicMakerSM_GoBackToStart;
} /* end MiniMusicMakerSM_Error() */

/*--------------------------------------------------------------------------------------------------------------------*/
/* End of File                                                                                                        */
/*--------------------------------------------------------------------------------------------------------------------*/
